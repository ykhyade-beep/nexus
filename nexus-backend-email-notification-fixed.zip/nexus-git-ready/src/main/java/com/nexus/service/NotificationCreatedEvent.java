package com.nexus.service;

/** Event published when an in-app notification has been saved. */
public record NotificationCreatedEvent(
        String recipientEmail,
        String recipientName,
        String title,
        String message,
        String link
) {}
