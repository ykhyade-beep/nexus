package com.nexus.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Service
public class EmailNotificationService {

    private static final Logger logger = LoggerFactory.getLogger(EmailNotificationService.class);

    private final JavaMailSender mailSender;

    @Value("${app.email.enabled:false}")
    private boolean emailEnabled;

    @Value("${app.email.from:}")
    private String fromAddress;

    public EmailNotificationService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void sendNotificationEmail(NotificationCreatedEvent event) {
        if (!emailEnabled) {
            logger.debug("Email notifications are disabled; skipped email for notification '{}'.", event.title());
            return;
        }

        if (event.recipientEmail() == null || event.recipientEmail().isBlank()) {
            logger.warn("Cannot send notification email because the recipient email is blank.");
            return;
        }

        try {
            SimpleMailMessage email = new SimpleMailMessage();
            if (fromAddress != null && !fromAddress.isBlank()) {
                email.setFrom(fromAddress);
            }
            email.setTo(event.recipientEmail());
            email.setSubject(event.title() == null || event.title().isBlank() ? "NEXUS notification" : event.title());
            StringBuilder body = new StringBuilder();
            body.append("Hello");
            if (event.recipientName() != null && !event.recipientName().isBlank()) {
                body.append(' ').append(event.recipientName().trim());
            }
            body.append(",\n\n");
            if (event.message() != null && !event.message().isBlank()) {
                body.append(event.message()).append("\n\n");
            }
            if (event.link() != null && !event.link().isBlank()) {
                body.append("Open NEXUS to view this notification: ").append(event.link()).append("\n\n");
            }
            body.append("\nThanks,\nNEXUS");
            email.setText(body.toString());
            mailSender.send(email);
        } catch (MailException | IllegalArgumentException ex) {
            // Email is best-effort: it must not undo a committed in-app notification.
            logger.warn("Failed to send notification email to {}: {}", event.recipientEmail(), ex.getMessage());
        }
    }
}
